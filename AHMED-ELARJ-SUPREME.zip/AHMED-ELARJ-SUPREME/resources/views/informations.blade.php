@extends('layout')



@section('contenu')
<br>

<!-- Modal -->
<div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalCenterTitle"><img src="https://fr.seaicons.com/wp-content/uploads/2017/02/close-icon.png" style="width : 15%;"></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        😬😱 Êtes vous sûr de vouloir supprimer cet étudiant ?
      </div>
      <div class="modal-footer">
        <form action='/accueil' method="post">
          {{csrf_field()}}
        <input  type="hidden" name="num_etudiant" value="{{$num_etudiant}}" >

        <button type="button" class="btn btn-secondary" data-dismiss="modal">Fermer</button>

        <button type="submit" class="btn btn-danger"  name="supprimer_etudiant" value="supprimer_etudiant">Confirmer</button>
        <form>
      </div>
    </div>
  </div>
</div>




@if($errors->any())
<div class="card mx-auto " style="width: 35rem;">
<small class="form-text text-danger text-center"> {{$errors->first()}} </small>
</div>
@endif
<div class="card mx-auto " style="width: 35rem;">
  <div class="card-header">
   <img style="width: 7%;"  src="https://image.flaticon.com/icons/png/512/46/46955.png">
  </div>
  <div class="card-body">

      <table class="table">

  <tbody>
    <tr>
      <td>Numero étudiant</td>
      <td id='num_etudiant'>38015545</td>
    </tr>
    <tr>
      <td>Nom</td>
      <td id='nom'>AHMED</td>
    </tr>
    <tr>
      <td>Prénom</td>
      <td id='prenom'></td>
    </tr>
    <tr>
      <td>Date de naissance</td>
      <td id='date_naissance'></td>
    </tr>
    <tr>
      <td>Mail interne</td>
      <td id='mail_interne'></td>
    </tr>
    <tr>
      <td>Mail externe</td>
      <td id='mail_externe'></td>
    </tr>
    <tr>
      <td>Adresse</td>
      <td id='adresse'></td>
    </tr>
    <tr>
      <td>Téléphone</td>
      <td id='tel'></td>
    </tr>
    <tr>
      <td>Diplomé</td>
      <td id='diplome'></td>
    </tr>
  </tbody>
</table>


</div>
  <div class="card-footer bg-transparent border-success ">
    <ul class="list-group list-group-horizontal " >
      <li class="list-group-item border-0 border-left-0 text-center" style="width: 33.33%;"><a href="/modifier/{{$num_etudiant}}"> Modifier</a></li>
      <li class="list-group-item border-0 text-center" style="width: 33.33%;"><a href="/parcours/{{$num_etudiant}}">Parcours</a></li>
      <li class="list-group-item border-0 text-center " data-toggle="modal" data-target="#exampleModalCenter" style="width: 33.33%;"><a href="#"> Supprimer</a></li>
    </ul>
  </div>
</div>
<div id="demo">
</div>




<script type="text/javascript">

var miagiste = @json($miagiste);
var num = {{$num_etudiant}};
var annee_diplome={{$annee_diplome}};

for(var i=0; i<miagiste.length; i++){
  var num_etudiant=miagiste[i].id_miagiste;
  if(num==num_etudiant){
    var nom=miagiste[i].nom;
    var prenom=miagiste[i].prenom;
    var date_naissance=miagiste[i].date_naissance;
    var mail_interne=miagiste[i].mail_interne;
    var mail_externe=miagiste[i].mail_externe;
    var adresse=miagiste[i].adresse;
    if(miagiste[i].tel!=null){
      var tel="0"+miagiste[i].tel;
    }
    else{
      var tel=miagiste[i].tel;
    }
    var diplome=miagiste[i].diplome;

    if (diplome==null) diplome = "Non";
    else {
      if(annee_diplome==0){
        diplome="Non"
      }
      else{
          diplome=annee_diplome;
      }
    }

    document.getElementById("num_etudiant").innerHTML=num_etudiant;
    document.getElementById("nom").innerHTML=nom;
    document.getElementById("prenom").innerHTML=prenom;
    document.getElementById("date_naissance").innerHTML=date_naissance;
    document.getElementById("mail_interne").innerHTML=mail_interne;
    document.getElementById("mail_externe").innerHTML=mail_externe;
    document.getElementById("adresse").innerHTML=adresse;
    document.getElementById("tel").innerHTML=tel;
    document.getElementById("diplome").innerHTML=diplome;
    //col-sm-4
  }
}

</script>

@endsection
