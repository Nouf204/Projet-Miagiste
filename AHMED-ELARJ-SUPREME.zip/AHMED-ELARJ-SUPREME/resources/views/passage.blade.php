@extends('layout')


@section('contenu')
<br>



<form action='/accueil' method="post">
  {{csrf_field()}}
  <div class="mx-auto" >
  <div class="card mx-auto" style="width: 50%;" >
    <div class="card-header">
     <img style="width: 5%;"  src="https://image.flaticon.com/icons/png/512/46/46955.png">
    </div>
    <div class="card-body mx-auto">
      <table class="table table-sm">
        <thead>
          <tr>
            <td class="text-center" >Diplome</td>
            <td class="text-center" >Numéro d'étudiant</td>
            <td class="text-center" >Nom Prénom</td>
            <td class="text-center" >Promo</td>
            <td class="text-center">Voie</td>
            <td class="text-center" >Année</td>
          </tr>
        </thead>
        <tbody>

          @foreach($etudiants as $etudiant)

            @if($etudiant->id_miagiste!=0)

            <tr class='table-hover'>
              @if($etudiant->libelle=='M2')

              <td class="text-center" ><input type="checkbox" name="choix[]" value="{{$etudiant->id_miagiste}}"></td>


              @else
              <td></td>

              @endif


              <td class="text-center"><input type="hidden" name="num_etudiants[]" value="{{ $etudiant->id_miagiste }}" >{{ $etudiant->id_miagiste }}</td>
              <td class="text-center">{{ $etudiant->nom }} {{ $etudiant->prenom}}</textarea> </td>
              <td class="text-center" >
                <select name="promotions[]">
                  <option >{{  $etudiant->libelle }}</option>
                  @if($etudiant->libelle=='L3')
                  <option >M1</option>
                  @elseif($etudiant->libelle=='M1')
                  <option >M2</option>
                  @else
                  @endif
                </select>
              </td>
              <td class="text-center" >
                <select name="voies[]">
                  <option value="{{ $etudiant->voie }}">{{ $etudiant->voie }}</option>
                  <option >
                    @if($etudiant->voie == 'APP') Class @else APP  @endif
                  </option>
                </select>
              </td>
              <td class="text-center" >
                <select name="annees[]">
                  <option value="{{ $etudiant->annee }}">{{ $etudiant->annee }}</option>
                  <option >
                    {{ $etudiant->annee +1 }}
                  </option>
                </select>
              </td>
           </tr>
           @endif
          @endforeach
        </tbody>
      </table>

    </div>
    <div class="card-footer bg-transparent border-success ">
      <ul class="list-group list-group-horizontal " >
        <li class="list-group-item border-0 border-left-0 text-center" style="width: 50%;">
        <input type="submit" class="btn btn-outline-info btn-block" value="Diplome" name="diplome">
        </li>
        <li class="list-group-item border-0 border-left-0 text-center" style="width: 50%;">
          <input type="submit" class="btn btn-outline-info btn-block" value="Passer" name="passer">
        </li>
      </ul>
    </div>
  </div>
</div>
</form>


@endsection
