@extends('layout')

@section('contenu')
<br>

<form action="/informations/{{$num_etudiant}}" method="post" >
    {{ csrf_field ()}}
  <div class="card mx-auto" style="width: 35rem;">
    {{ csrf_field ()}}

    <div class="card-header">
     <img style="width: 7%;"  src="https://image.flaticon.com/icons/png/512/46/46955.png">
    </div>
    <div class="card-body">

        <table class="table table-sm">
          <tbody>
            <tr>
              <td>Numero étudiant</td>
              <td id='num_etudiant'></td>
            </tr>
            <tr>
              <td>Nom</td>
              <td >
                <input id='nom' type="text" class="form-control" name='nom' >
                @if($errors->has('nom'))
                  <small  class="form-text text-danger">Le nom ne doit pas comporter un entier</small>
                @endif
              </td>
            </tr>
            <tr>
              <td>Prénom</td>
              <td >
                <input id='prenom' type="text" class="form-control" name='prenom' >
                @if($errors->has('prenom'))
                  <small  class="form-text text-danger">Le prénom ne doit pas comporter un entier</small>
                @endif
              </td>
            </tr>
            <tr>
              <td>Date de naissance</td>
              <td >
                <input type="date" id='date_naissance' class="form-control" name='date_naissance' >
              </td>
            </tr>
            <tr>
              <td>Mail interne</td>
              <td>
                <select  class="custom-select"  name='mail_interne' id="selection">
                  <option id='mail_interne1' value="mail1" ></option>
                  <option id='mail_interne2' value="mail2">2</option>
                  <option id='mail_interne3' value="mail3">3</option>
                </select>
              </td>
            </tr>
            <tr>
              <td>Mail externe</td>
              <td >
                <input id='mail_externe' type="email" class="form-control" name='mail_externe'>
                @if($errors->has('mail_externe'))
                  <small  class="form-text text-danger">Le mail est invalide </small>
                @endif
              </td>
            </tr>
            <tr>
              <td>Adresse</td>
              <td >
                <input id='adresse' type="text" class="form-control" name='adresse' >
              </td>
            </tr>
            <tr>
              <td>Téléphone</td>
              <td >
                <div class="input-group mb-1 ">
                  <div class="input-group-prepend">
                    <span class="input-group-text">+33</span>
                  </div>
                    <input id='tel' type="text" class="form-control" name='tel'>
                </div>
                @if($errors->has('tel'))
                  <small  class="form-text text-danger">Le numéro doit etre un entier sous la forme 0XXXXXXXXX</small>
                @endif
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    <div class="card-footer bg-transparent border-success ">
      <input type="submit" class="btn btn-outline-info btn-block" value="Modifier">
    </div>
  </div>

</form>




<script type="text/javascript">
var miagiste = @json($miagiste);
var num = {{$num_etudiant}};
var i=0;
while(miagiste[i].id_miagiste!=num){
    //col-sm-4
    i++;
}
var num_etudiant=miagiste[i].id_miagiste;
var nom=miagiste[i].nom;
var prenom=miagiste[i].prenom;
var date_naissance=miagiste[i].date_naissance;
var mail_interne=miagiste[i].mail_interne;
var mail_externe=miagiste[i].mail_externe;
var adresse=miagiste[i].adresse;

if(miagiste[i].tel!=null){
  var tel="0"+miagiste[i].tel;
}
else{
  var tel=miagiste[i].tel;
}

document.getElementById("num_etudiant").innerHTML=num_etudiant;
document.getElementById("nom").value=nom;
document.getElementById("prenom").value=prenom;
document.getElementById("date_naissance").value=date_naissance;




switch (mail_interne) {
  case nom.toLowerCase()+"."+prenom.toLowerCase()+"@parisnanterre.fr":
    document.getElementById("mail_interne1").innerHTML=nom.toLowerCase()+"."+prenom.toLowerCase()+"@parisnanterre.fr";
    document.getElementById("mail_interne1").value=nom.toLowerCase()+"."+prenom.toLowerCase()+"@parisnanterre.fr";

    document.getElementById("mail_interne2").innerHTML=prenom.toLowerCase()+"."+nom.toLowerCase()+"@parisnanterre.fr";
    document.getElementById("mail_interne2").value=prenom.toLowerCase()+"."+nom.toLowerCase()+"@parisnanterre.fr";

    document.getElementById("mail_interne3").innerHTML=num_etudiant+"@parisnanterre.fr";
    document.getElementById("mail_interne3").value=num_etudiant+"@parisnanterre.fr";

    break;
  case prenom.toLowerCase()+"."+nom.toLowerCase()+"@parisnanterre.fr":
    document.getElementById("mail_interne1").innerHTML=nom.toLowerCase()+"."+prenom.toLowerCase()+"@parisnanterre.fr";
    document.getElementById("mail_interne1").value=nom.toLowerCase()+"."+prenom.toLowerCase()+"@parisnanterre.fr";

    document.getElementById("mail_interne2").innerHTML=prenom.toLowerCase()+"."+nom.toLowerCase()+"@parisnanterre.fr";
    document.getElementById("mail_interne2").value=prenom.toLowerCase()+"."+nom.toLowerCase()+"@parisnanterre.fr";

    document.getElementById("mail_interne3").innerHTML=num_etudiant+"@parisnanterre.fr";
    document.getElementById("mail_interne3").value=num_etudiant+"@parisnanterre.fr";

    break;
    case num_etudiant+"@parisnanterre.fr":
    document.getElementById("mail_interne1").innerHTML=num_etudiant+"@parisnanterre.fr";
    document.getElementById("mail_interne1").value=num_etudiant+"@parisnanterre.fr";

    document.getElementById("mail_interne2").innerHTML=prenom.toLowerCase()+"."+nom.toLowerCase()+"@parisnanterre.fr";
    document.getElementById("mail_interne2").value=prenom.toLowerCase()+"."+nom.toLowerCase()+"@parisnanterre.fr";

    document.getElementById("mail_interne3").innerHTML=nom.toLowerCase()+"."+prenom.toLowerCase()+"@parisnanterre.fr";
    document.getElementById("mail_interne3").value=nom.toLowerCase()+"."+prenom.toLowerCase()+"@parisnanterre.fr";
  default:
    var option = document.createElement("option");
    var texte = document.createTextNode(nom.toLowerCase()+"."+prenom.toLowerCase()+"@parisnanterre.fr");
    option.appendChild(texte);
    var selection = document.getElementById("selection");
    selection.insertBefore(option, document.getElementById("mail_interne2"));

    document.getElementById("mail_interne1").innerHTML="";
    document.getElementById("mail_interne1").value="";

    document.getElementById("mail_interne2").innerHTML=prenom.toLowerCase()+"."+nom.toLowerCase()+"@parisnanterre.fr";
    document.getElementById("mail_interne2").value=prenom.toLowerCase()+"."+nom.toLowerCase()+"@parisnanterre.fr";

    document.getElementById("mail_interne3").innerHTML=num_etudiant+"@parisnanterre.fr";
    document.getElementById("mail_interne3").value=num_etudiant+"@parisnanterre.fr";

}


document.getElementById("mail_externe").value=mail_externe;
document.getElementById("adresse").value=adresse;
document.getElementById("tel").value=tel;

</script>





@endsection
