@extends('layout')


@section('contenu')




<br>


<!-- Modal -->
<div  class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" ><img src="https://fr.seaicons.com/wp-content/uploads/2017/02/close-icon.png" style="width : 15%;"></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        😬😱 Êtes vous sûr de vouloir supprimer ce.t.s étudiant.s de la base ?
      </div>
      <form action='/modification/{{$annee}}/{{$promo}}/{{$annee}}' method="post">
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Fermer</button>
        <button type="submit" formaction="/accueil" class="btn btn-primary" name="supprimer_etudiants" value="supprimer_etudiants"> Confirmer</button></a>
      </div>
    </div>
  </div>
</div>





  {{csrf_field()}}
  <div class="card mx-auto" style="width: 70rem;">
    <div class="card-header">
     <img style="width: 5%;"  src="https://image.flaticon.com/icons/png/512/46/46955.png">
     <h4>Liste des Étudiants de la {{$promo}} {{$voie}} {{$annee}}</h4>
     @if($errors->any())
     <small class="form-text text-danger text-center"> {{$errors->first()}} </small>
     @endif
    </div>
    <div class="card-body ">
      <table class="table table-sm table-hover">
        <thead>
          <tr>
            <td class="text-center" ></td>
            <td class="text-center" >Numéro d'étudiant</td>
            <td class="text-center" >Nom Prénom</td>
            <td class="text-center" >Entreprise</td>
            <td class="text-center" >Mission</td>
            <td class="text-center" >Description</td>
            <td class="text-center" >Maitre d'apprentissage</td>
            <td class="text-center" >Date début</td>
            <td class="text-center" >Date fin</td>
          </tr>
        </thead>
        <tbody>
          @foreach($etudiants_avec_mission as $etudiant)

            <tr class='table-hover'>
              <td class="text-center" ><input type="checkbox" name="choix[]" value="{{$etudiant->id_miagiste}}"></td>

              <input type="hidden" name="id_promotion[]" value="{{$etudiant->id_promotion}}">
              <input type="hidden" name="id_mission[]" value="{{$etudiant->id_mission}}">


              <td class="text-center">{{ $etudiant->id_miagiste }}</td>
              <td class="text-center">{{ $etudiant->nom }} {{ $etudiant->prenom }}</td>
              <td class="text-center">{{ $etudiant->nom_entreprise }}</td>
              <td class="text-center">{{ $etudiant->titre }}</td>
              <td class="text-center">{{ $etudiant->description }}</td>
              <td class="text-center">{{ $etudiant->maitre_apprentissage}}</td>
              <td class="text-center">{{ $etudiant->date_debut}}</td>
              <td class="text-center">{{ $etudiant->date_fin}}</td>
           </tr>
          @endforeach
          @foreach($etudiants_sans_mission as $etudiant)

            <tr class='table-hover'>
              <td class="text-center" ><input type="checkbox" name="choix[]" value="{{$etudiant->id_miagiste}}"></td>
             <td class="text-center">{{ $etudiant->id_miagiste }}</td>
             <td class="text-center">{{ $etudiant->nom }} {{ $etudiant->prenom }}</td>
             <td></td>
             <td></td>
             <td></td>
             <td></td>
             <td></td>
             <td></td>
           </tr>
          @endforeach
        </tbody>
      </table>
    </div>
    <div class="card-footer bg-transparent border-success ">
      <ul class="list-group list-group-horizontal " >
        <li class="list-group-item border-0 border-left-0 text-center" style="width: 25%;">
          <input type="submit" class="btn btn-outline-info btn-block" value="Modifier Mission" name="modifier_mission">
        </li>
        <li class="list-group-item border-0 border-left-0 text-center" style="width: 25%;">
          <input type="submit" formaction="/ajout" class="btn btn-outline-info btn-block" value="Ajouter Mission">
        </li>
        <li class="list-group-item border-0 border-left-0 text-center" style="width: 25%;">
          <input type="submit" formaction="/passage"  class="btn btn-outline-info btn-block" value="Passer Classe Sup">
        </li>
        <li  class="list-group-item border-0 border-left-0 text-center" style="width: 25%;">
          <input type="button"  data-toggle="modal" data-target="#exampleModalCenter"  formaction="/passage"  class="btn btn-outline-danger btn-block" value="Supprimer">

        </li>
      </ul>
    </div>
  </div>
</form>




<script>





</script>



















@endsection
