@extends('layout')


@section('contenu')
<br>



<form action='/accueil' method="post">
  {{csrf_field()}}
  <div class="mx-auto" >
  <div class="card mx-auto" style="width: 85%;" >
    <div class="card-header">
     <img style="width: 5%;"  src="https://image.flaticon.com/icons/png/512/46/46955.png">
    </div>
    <div class="card-body mx-auto">
      <table class="table table-sm">
        <thead>
          <tr>
            <td class="text-center" style="width: 12.5%;">Numéro d'étudiant</td>
            <td class="text-center" style="width: 12.5%;">Nom Prénom</td>

            <td class="text-center" style="width: 12.5%;">Entreprise</td>
            <td class="text-center" style="width: 12.5%;">Mission</td>
            <td class="text-center" style="width: 12.5%;">Description</td>
            <td class="text-center" style="width: 12.5%;">Maitre d'apprentissage</td>
            <td class="text-center" >Date début</td>
            <td class="text-center" >Date fin</td>

          </tr>
        </thead>
        <tbody>


         @foreach($nom as $n)
            <tr class='table-hover'>

              <td class="text-center"><input type="hidden" name="num_etudiants[]" value="{{ $n->id_miagiste}}">{{ $n->id_miagiste}}</td>
              <td class="text-center"> {{$n->nom}} {{$n->prenom}}</td>

              <td class="text-center">
                <input list="noms_entreprises" name="noms_entreprises[]" required>
                  <datalist id="noms_entreprises">
                    @foreach ($liste_entreprises as $entreprise)
                    <option value="{{$entreprise->nom_entreprise}}">
                    @endforeach
                  </datalist>
                </td>


                <td class="text-center">
                  <input list="titres" name="titres[]" required>
                    <datalist id="titres">
                      @foreach ($liste_missions as $mission)
                      <option value="{{$mission->titre}}">
                      @endforeach
                    </datalist>
                  </td>

<!--
              <td class="text-center"><textarea name="titres[]" class="form-control" rows="1" value="" required=""></textarea></td>
-->
              <td class="text-center"><textarea name="descriptions[]" class="form-control" rows="1" value=""></textarea></td>
              <td class="text-center"><textarea name="maitres_apprentissages_avec_mission[]" class="form-control" rows="1" value="" ></textarea></td>
              <td class="text-center"><input name="dates_debuts[]"  type="date" value="" required></td>
              <td class="text-center"><input name="dates_fins[]" type="date" value="" required></td>
              <td class="text-center invisible"><input  type="hidden" name="id_missions[]" value="" ></td>
              <td class="text-center invisible"><input type="hidden" name="id_promotions[]" value="" ></td>

           </tr>
          @endforeach

        </tbody>
      </table>
    </div>
    <div class="card-footer bg-transparent border-success ">
      <ul class="list-group list-group-horizontal " >
        <input type="submit" class="btn btn-outline-info btn-block" value="Ajouter" name="ajouter">
      </ul>
    </div>
  </div>
</div>
</form>


@endsection
