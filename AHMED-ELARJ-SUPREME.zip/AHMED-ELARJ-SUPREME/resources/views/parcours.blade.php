@extends('layout')

@section('contenu')
<br>
<div class="card mx-auto" style="width: 70rem;">
    <div class="card-header">
      <h5>
     <img style="width: 7%;"  src="https://image.flaticon.com/icons/png/512/46/46955.png">
      {{$parcours[0]->nom  }} {{$parcours[0]->prenom}}</h5>
    </div>
    <div class="card-body">

        <table class="table">

    <tbody>
      <tr >
        <td class="text-center"><b>Année</b></td>
        <td class="text-center"><b>Promotion</b></td>
        <td class="text-center"><b>Voie</b></td>
        <td class="text-center"><b>Entreprise</b></td>
        <td class="text-center"><b>Mission</b></td>
        <td class="text-center"><b>Description</b></td>
        <td class="text-center"><b>Maitre d'apprentissage</b></td>
        <td class="text-center"><b>Date debut</b></td>
        <td class="text-center"><b>Date fin</b></td>

      </tr>

      @foreach($carriere as $row)
      <?php if($derniere_annee+1 < date("Y",strtotime($row->date_debut))){ ?>
      <tr>
       <td class="text-center"></td>
       <td class="text-center"></td>
       <td class="text-center"></td>
       <td class="text-center">{{$row->nom_entreprise}}</td>
       <td class="text-center">{{$row->titre}}</td>
       <td class="text-center">{{$row->description}}</td>
       <td class="text-center">{{$row->maitre_apprentissage}}</td>
       <td class="text-center">{{$row->date_debut}}</td>
       <td class="text-center"></td>

      </tr>
        <?php } ?>
      @endforeach


<?php if(count($parcours)>0){  ?>
      @foreach($parcours as $row)

      <?php if($row->annee == date("Y",strtotime($row->date_fin))-1){ ?>
      <tr>
       <td class="text-center">{{ $row->annee }}</td>
       <td class="text-center">{{ $row->libelle }}</td>
       <td class="text-center">{{ $row->voie }}</td>
       <td class="text-center">{{ $row->nom_entreprise }}</td>
       <td class="text-center">{{ $row->titre }}</td>
       <td class="text-center">{{ $row->description }}</td>
       <td class="text-center">{{ $row->maitre_apprentissage }}</td>
       <td class="text-center">{{ $row->date_debut }}</td>
       <td class="text-center">{{ $row->date_fin }}</td>
      </tr>
    <?php } ?>
      @endforeach
<?php } ?>
    </tbody>
  </table>
  <div class="card-footer bg-transparent border-success ">
    <ul class="list-group list-group-horizontal " >
    <button class="btn btn-outline-info " style="width: 100%;" value="Modifier"><a href="/ajout-parcours/{{$num_etudiant}}"> Ajout Parcours</a></button>&nbsp;&nbsp;&nbsp;
    </ul>
  </div>
  </div>

  </div>










<script>

</script>



@endsection
