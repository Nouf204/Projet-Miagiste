@extends('layout')


@section('contenu')
<br>

<form action="accueil" method="post" >
    {{ csrf_field ()}}
    
    @if($errors->any())
    <div class="card mx-auto " style="width: 35rem;">
    <small class="form-text text-danger text-center"> {{$errors->first()}} </small>
    </div>
    @endif

  <div class="card mx-auto" style="width: 35rem;">


    {{ csrf_field ()}}

    <div class="card-header">
     <img style="width: 7%;"  src="https://image.flaticon.com/icons/png/512/46/46955.png">
    </div>

    <div class="card-body">
        <table class="table table-sm">
          <tbody>
            <tr>
              <td>Numéro </td>
              <td>
                <input type="text" class="form-control" name='id_miagiste' >
                @if($errors->has('id_miagiste'))
                  <small  class="form-text text-danger">Le numéro doit etre un entier</small>
                @endif
              </td>
            </tr>
            <tr>
              <td>Nom</td>
              <td>
                <input type="text" class="form-control" name='nom' >
                @if($errors->has('nom'))
                  <small  class="form-text text-danger">Le nom est obligatoire et ne doit pas comporter un entier</small>
                @endif
              </td>
            </tr>
            <tr>
              <td>Prénom</td>
              <td >
                <input type="text" class="form-control" name='prenom' >
                @if($errors->has('prenom'))
                  <small  class="form-text text-danger">Le prénom est obligatoire et ne doit pas comporter un entier</small>
                @endif
              </td>
            </tr>

            <tr>
              <td>Date de naissance</td>
              <td >
                <input type="date"  class="form-control" name='date_naissance' >
              </td>
            </tr>
            <tr>
              <td>Mail externe</td>
              <td >
                <input id='mail_externe' type="email" class="form-control" name='mail_externe'>
                @if($errors->has('mail_externe'))
                  <small  class="form-text text-danger">Le mail est invalide </small>
                @endif
              </td>
            </tr>
            <tr>
              <td>Adresse</td>
              <td >
                <input type="text" class="form-control" name='adresse' >
              </td>
            </tr>
            <tr>
              <td>Téléphone</td>
              <td >
                <div class="input-group mb-1 ">
                  <div class="input-group-prepend">
                    <span class="input-group-text">+33</span>
                  </div>
                    <input id='tel' type="text" class="form-control" name='tel'>
                </div>
                @if($errors->has('tel'))
                  <small  class="form-text text-danger">Le numéro doit etre un entier sous la forme 0XXXXXXXXX</small>
                @endif
              </td>
              </tr>
              <tr>
              <td>Promotion</td>
              <td>
                <select  class="custom-select"  name='promotion'>
                  <option  value="L3">L3</option>
                  <option value="M1">M1</option>
                  <option  value="M2">M2</option>
                </select>
              </td>
            </tr>
            <tr>
            <td>Annee</td>
            <td>
              <select  class="custom-select"  name='annee' >
                <option  value="2019">2019</option>
                <option value="2018">2018</option>
                <option  value="2017">2017</option>
                <option  value="2016">2016</option>
                <option value="2015">2015</option>
              </select>
            </td>
          </tr>
          <tr>
          <td>Voie</td>
          <td>
            <select  class="custom-select"  name='voie'
              <option  value="APP">APP</option>
              <option value="Class">Class</option>
            </select>
          </td>
        </tr>
          </tbody>
        </table>
      </div>
    <div class="card-footer bg-transparent border-success ">
      <input type="submit" class="btn btn-outline-info btn-block" value="ajouter" name="ajouter_etudiant">
    </div>

  </div>
</form>


@endsection
