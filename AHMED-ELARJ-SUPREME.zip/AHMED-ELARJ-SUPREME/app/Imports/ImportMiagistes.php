<?php

namespace App\Imports;

use App\Miagiste;
use Maatwebsite\Excel\Concerns\ToModel;
use Illuminate\Support\Facades\DB;

class ImportMiagistes implements ToModel
{
    /**
    * @param array $row
    *
    * @return \Illuminate\Database\Eloquent\Model|null
    */


    public function model(array $row)
    {
        //ne pas prendre la première ligne
        if(@$row[0]!='NumEtu'){

          DB::table('Miagiste')->updateOrInsert(['id_miagiste' => @$row[0]],
          ['id_miagiste' => @$row[0], 'nom' => @$row[1], 'prenom' => @$row[2]]);



          //DB::insert('insert into promos (libelle, voie) values (?, ?)', [@$row[3], @$row[4]]);

          DB::table('Promotion')->updateOrInsert(['libelle' => @$row[3], 'voie' => @$row[4], 'annee' => @$row[5]],
          ['libelle' => @$row[3], 'voie' => @$row[4],'annee' => @$row[5]]);


          $id_promo=DB::table('Promotion')
                        ->where('libelle', @$row[3])
                        ->where('voie', @$row[4])
                        ->where('annee', @$row[5])
                        ->take(1)
                        ->value('id_promotion');

        //  DB::insert('insert into Est_de_passage (id_miagiste, id_promotion) values (?, ?)', [@$row[0],$id_promo]);

          DB::table('Est_de_passage')->updateOrInsert(['id_miagiste' => @$row[0], 'id_promotion'=>$id_promo],
          ['id_miagiste' => @$row[0], 'id_promotion'=>$id_promo]);



    }
  }
}
