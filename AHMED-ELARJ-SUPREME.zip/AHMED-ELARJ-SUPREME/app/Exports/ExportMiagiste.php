<?php

namespace App\Exports;
use Illuminate\Support\Facades\DB;


use App\Miagiste;
use App\Promotion;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;

class ExportMiagiste implements FromCollection, WithHeadings
{

    public function collection()
    {


$resultat2 =DB::table('Miagiste')
                  ->leftjoin('Effectue','Effectue.id_miagiste','=','Miagiste.id_miagiste')
                  ->leftjoin('Est_de_passage','Est_de_passage.id_miagiste','=','Miagiste.id_miagiste')
                  ->leftjoin('Promotion','Promotion.id_promotion','=','Est_de_passage.id_promotion')
                  ->leftjoin('Mission','Mission.id_mission','=','Effectue.id_mission')
                  ->leftjoin('Entreprise','Entreprise.id_entreprise','=','Mission.id_entreprise')
                  ->where('Promotion.annee',request('annee'))
                   ->where('Promotion.libelle',request('libelle'))
                  ->where('Promotion.voie',request('voie'))
                  ->get();
            return $resultat2;
    }



public function headings():array{

      return [
        'NumEtu    ',
        'NomEtu    ',
        'PrenomEtu ',
        'Mail_externe',
        'Mail_interne',
        'Date de naissance',
        'Adresse',
        'Numero tel',
        'Diplome',
        ' ',
        'id_promotion',
        'Promotion',
        'Voie ',
        'Annee',
        'id_mission',
        'Type',
        'Thematique',
        'Titre',
        'Description',
        'Maitre apprentissage',
        'Date debut',
        'Date fin',
        'id_entreprise',
        'Entreprise'

      ];
    }

}
