<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Miagiste;
use DB;
use App\Exports\ExportMiagiste;
use Maatwebsite\Excel\Facades\Excel;

class ExportExcelController extends Controller
{

    public function exportView()
    {

    $miagiste = Miagiste::orderBy('id_miagiste','DESC')->get();
    $premiere_annee=DB::table('Promotion')->orderBy('annee','asc')->take(1)->value('annee');

       return view('export',compact('miagiste','premiere_annee'));

    }

    public function export()
    {
        return Excel::download(new ExportMiagiste, 'Miagistes.xls');
    }

}
