<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Imports\ImportMiagistes;
use Maatwebsite\Excel\Facades\Excel;
use DB;
use App\Miagiste;

class ImportExcelController extends Controller

{

    public function index()
    {
        $miagiste = Miagiste::orderBy('id_miagiste','DESC')->get();
        $premiere_annee=DB::table('Promotion')->orderBy('annee','asc')->take(1)->value('annee');

        return view('import_excel.index',compact('miagiste','premiere_annee'));
    }


    public function import(Request $request)
    {
        $request->validate([
            'import_file' => 'required|mimes:xls,xlsx'
        ]);

        Excel::import(new ImportMiagistes, request()->file('import_file'));


        return back()->with('success', ' ✅ Importation réussi ✌🏻🎉');
    }


}
