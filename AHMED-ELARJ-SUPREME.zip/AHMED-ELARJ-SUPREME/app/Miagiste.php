<?php
namespace App;
use Illuminate\Database\Eloquent\Model;
class Miagiste extends Model
{
    protected $fillable = ['id_miagiste', 'nom', 'prenom','mail_externe','mail_interne',
    'date_naissance','adresse','tel','diplome'];

    protected $table = "miagiste";

    //pour desactiver les variable created_at et updated_at
    public $timestamps = false;




    ////getting user id of jane smith
    ////$user_id=DB::table('users')->where('name', 'jane')->take(1)->value('id');
    //$users = DB::table('users')
                    //->where('votes', '>', 100)
                    //->orWhere('name', 'John')
                    //->get();
    //https://laravel.com/docs/4.2/queries

}
