<?php $__env->startSection('contenu'); ?>
<br>
<div class="card mx-auto" style="width: 70rem;">
    <div class="card-header">
      <h5>
     <img style="width: 7%;"  src="https://image.flaticon.com/icons/png/512/46/46955.png">
      <?php echo e($parcours[0]->nom); ?> <?php echo e($parcours[0]->prenom); ?></h5>
    </div>
    <div class="card-body">

        <table class="table">

    <tbody>
      <tr >
        <td class="text-center"><b>Année</b></td>
        <td class="text-center"><b>Promotion</b></td>
        <td class="text-center"><b>Voie</b></td>
        <td class="text-center"><b>Entreprise</b></td>
        <td class="text-center"><b>Mission</b></td>
        <td class="text-center"><b>Description</b></td>
        <td class="text-center"><b>Maitre d'apprentissage</b></td>
        <td class="text-center"><b>Date debut</b></td>
        <td class="text-center"><b>Date fin</b></td>

      </tr>

      <?php $__currentLoopData = $carriere; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php if($derniere_annee+1 < date("Y",strtotime($row->date_debut))){ ?>
      <tr>
       <td class="text-center"></td>
       <td class="text-center"></td>
       <td class="text-center"></td>
       <td class="text-center"><?php echo e($row->nom_entreprise); ?></td>
       <td class="text-center"><?php echo e($row->titre); ?></td>
       <td class="text-center"><?php echo e($row->description); ?></td>
       <td class="text-center"><?php echo e($row->maitre_apprentissage); ?></td>
       <td class="text-center"><?php echo e($row->date_debut); ?></td>
       <td class="text-center"></td>

      </tr>
        <?php } ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<?php if(count($parcours)>0){  ?>
      <?php $__currentLoopData = $parcours; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

      <?php if($row->annee == date("Y",strtotime($row->date_fin))-1){ ?>
      <tr>
       <td class="text-center"><?php echo e($row->annee); ?></td>
       <td class="text-center"><?php echo e($row->libelle); ?></td>
       <td class="text-center"><?php echo e($row->voie); ?></td>
       <td class="text-center"><?php echo e($row->nom_entreprise); ?></td>
       <td class="text-center"><?php echo e($row->titre); ?></td>
       <td class="text-center"><?php echo e($row->description); ?></td>
       <td class="text-center"><?php echo e($row->maitre_apprentissage); ?></td>
       <td class="text-center"><?php echo e($row->date_debut); ?></td>
       <td class="text-center"><?php echo e($row->date_fin); ?></td>
      </tr>
    <?php } ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php } ?>
    </tbody>
  </table>
  <div class="card-footer bg-transparent border-success ">
    <ul class="list-group list-group-horizontal " >
    <button class="btn btn-outline-info " style="width: 100%;" value="Modifier"><a href="/ajout-parcours/<?php echo e($num_etudiant); ?>"> Ajout Parcours</a></button>&nbsp;&nbsp;&nbsp;
    </ul>
  </div>
  </div>

  </div>










<script>

</script>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/noufeine/Documents/ProjetMiagiste/resources/views/parcours.blade.php ENDPATH**/ ?>