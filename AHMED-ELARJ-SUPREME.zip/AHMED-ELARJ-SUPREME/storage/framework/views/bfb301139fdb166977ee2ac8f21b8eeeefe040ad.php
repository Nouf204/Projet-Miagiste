<?php $__env->startSection('contenu'); ?>
<br>



<form action='/accueil' method="post">
  <?php echo e(csrf_field()); ?>

  <div class="mx-auto" >
  <div class="card mx-auto" style="width: 85%;" >
    <div class="card-header">
     <img style="width: 5%;"  src="https://image.flaticon.com/icons/png/512/46/46955.png">
    </div>
    <div class="card-body mx-auto">
      <table class="table table-sm">
        <thead>
          <tr>
            <td class="text-center" style="width: 12.5%;">Numéro d'étudiant</td>
            <td class="text-center" style="width: 12.5%;">Nom Prénom</td>
            <td class="text-center" >Promo</td>
            <td class="text-center">Voie</td>
            <td class="text-center" >Année</td>
            <td class="text-center" style="width: 12.5%;">Entreprise</td>
            <td class="text-center" style="width: 12.5%;">Mission</td>
            <td class="text-center" style="width: 12.5%;">Description</td>
            <td class="text-center" style="width: 12.5%;">Maitre d'apprentissage</td>
            <td class="text-center" >Date début</td>
            <td class="text-center" >Date fin</td>

          </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $etudiants_avec_mission; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $etudiant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class='table-hover'>

              <td class="text-center"><input type="hidden" name="num_etudiants_avec_mission[]" value="<?php echo e($etudiant->id_miagiste); ?>" ><?php echo e($etudiant->id_miagiste); ?></td>
              <td class="text-center"><?php echo e($etudiant->nom); ?> <?php echo e($etudiant->prenom); ?></textarea> </td>
              <td class="text-center" >
                <select name="promotions_avec_mission[]">
                  <option ><?php echo e($etudiant->libelle); ?></option>
                  <?php if($etudiant->libelle=='L3'): ?>
                  <option >M1</option>
                  <option >M2</option>
                  <?php elseif($etudiant->libelle=='M1'): ?>
                  <option >L3</option>
                  <option >M2</option>
                  <?php else: ?>
                  <option >L3</option>
                  <option >M1</option>
                  <?php endif; ?>
                </select>
              </td>
              <td class="text-center" >
                <select name="voies_avec_mission[]">
                  <option value="<?php echo e($etudiant->voie); ?>"><?php echo e($etudiant->voie); ?></option>
                  <option >
                    <?php if($etudiant->voie == 'APP'): ?> Class <?php else: ?> APP  <?php endif; ?>
                  </option>
                </select>
              </td>
              <td class="text-center" >
                <select name="annees_avec_mission[]">
                  <option value="<?php echo e($etudiant->annee); ?>"><?php echo e($etudiant->annee); ?></option>
                  <option >
                    <?php if($etudiant->annee == 2019): ?> 2018 <?php else: ?> 2019  <?php endif; ?>
                  </option>
                </select>
              </td>
              <td class="text-center">
                <input list="noms_entreprises_avec_mission" name="noms_entreprises_avec_mission[]">
                  <datalist id="noms_entreprises_avec_mission">
                    <?php $__currentLoopData = $liste_entreprises; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entreprise): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($entreprise->nom_entreprise); ?>">
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </datalist>
              </td>
              <td class="text-center"><textarea name="titres_avec_mission[]" class="form-control" rows="1" value="<?php echo e($etudiant->titre); ?>"><?php echo e($etudiant->titre); ?></textarea></td>
              <td class="text-center"><textarea name="descriptions_avec_mission[]" class="form-control" rows="1" value="<?php echo e($etudiant->description); ?>"><?php echo e($etudiant->description); ?></textarea></td>
              <td class="text-center"><textarea name="maitres_apprentissages_avec_mission[]" class="form-control" rows="1" value="<?php echo e($etudiant->maitre_apprentissage); ?>"><?php echo e($etudiant->maitre_apprentissage); ?></textarea></td>
              <td class="text-center"><input name="dates_debuts_avec_mission[]"  type="date" value="<?php echo e($etudiant->date_debut); ?>" ></td>
              <td class="text-center"><input name="dates_fins_avec_mission[]" type="date" value="<?php echo e($etudiant->date_fin); ?>" ></td>
              <td class="text-center invisible"><input  type="hidden" name="id_missions_avec_mission[]" value="<?php echo e($etudiant->id_mission); ?>" ><?php echo e($etudiant->id_mission); ?></td>
              <td class="text-center invisible"><input type="hidden" name="id_promotions_avec_mission[]" value="<?php echo e($etudiant->id_promotion); ?>" ><?php echo e($etudiant->id_promotion); ?></td>

           </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php $__currentLoopData = $etudiants_sans_mission; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $etudiant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class='table-hover'>
              <td class="text-center"><input type="hidden" name="num_etudiants_sans_mission[]" value="<?php echo e($etudiant->id_miagiste); ?>" ><?php echo e($etudiant->id_miagiste); ?></td>
             <td class="text-center"> <?php echo e($etudiant->nom); ?> <?php echo e($etudiant->prenom); ?></td>
             <td class="text-center">
               <select name="promotions_sans_mission[]">
                 <option ><?php echo e($etudiant->libelle); ?></option>
                 <?php if($etudiant->libelle=='L3'): ?>
                 <option >M1</option>
                 <option >M2</option>
                 <?php elseif($etudiant->libelle=='M1'): ?>
                 <option >L3</option>
                 <option >M2</option>
                 <?php else: ?>
                 <option >L3</option>
                 <option >M1</option>
                 <?php endif; ?>
               </select>
             </td>
             <td class="text-center">
               <select name="voies_sans_mission[]">
                 <option value="<?php echo e($etudiant->voie); ?>"><?php echo e($etudiant->voie); ?></option>
                 <option>
                   <?php if($etudiant->voie == 'APP'): ?> Class <?php else: ?> APP  <?php endif; ?>
                 </option>
               </select>
             </td>
             <td class="text-center">
               <select name="annees_sans_mission[]">
                 <option value="<?php echo e($etudiant->annee); ?>"><?php echo e($etudiant->annee); ?></option>
                 <option >
                   <?php if($etudiant->annee == 2019): ?> 2018 <?php else: ?> 2019  <?php endif; ?>
                 </option>
               </select>
            </td>
            <td class="text-center">
              <input list="noms_entreprises_sans_mission" name="noms_entreprises_sans_mission[]">
                <datalist id="noms_entreprises_avec_mission">
                  <?php $__currentLoopData = $liste_entreprises; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entreprise): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($entreprise->nom_entreprise); ?>">
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </datalist>
            </td>
            <td class="text-center"><textarea name="titres_sans_mission[]" class="form-control" rows="1" ></textarea></td>
            <td class="text-center"><textarea name="descriptions_sans_mission[]" class="form-control" rows="1"></textarea></td>
            <td class="text-center"><textarea name="maitres_apprentissages_sans_mission[]" class="form-control" rows="1" ></textarea></td>
            <td class="text-center"><input name="dates_debuts_sans_mission[]"  type="date" ></td>
            <td class="text-center"><input name="dates_fins_sans_mission[]" type="date" ></td>
            <td class="text-center invisible"></td>
            <td class="text-center invisible"><input type="hidden" name="id_promotions_sans_mission[]" value="<?php echo e($etudiant->id_promotion); ?>" ><?php echo e($etudiant->id_promotion); ?></td>

           </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
    <div class="card-footer bg-transparent border-success ">
      <ul class="list-group list-group-horizontal " >
        <input type="submit" class="btn btn-outline-info btn-block" value="Modifier" name="modification">

      </ul>
    </div>
  </div>
</div>
</form>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/noufeine/Documents/ProjetMiagiste/resources/views/modification.blade.php ENDPATH**/ ?>