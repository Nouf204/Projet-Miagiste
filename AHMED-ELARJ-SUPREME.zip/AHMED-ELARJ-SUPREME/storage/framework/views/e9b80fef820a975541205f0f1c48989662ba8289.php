<!DOCTYPE html>
<html>


<?php $__env->startSection('contenu'); ?>
<head>
    <title>Export Excel </title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css" />
</head>
<body>


<div class="container">
    <div class="card bg-light mt-3">
        <div class="card-header">
          Exportation Excel
        </div>
        <h1>  </h1>
        <div class="card-body">
            <form action="<?php echo e(route('export')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>

                     <div>

                          <select name="annee">
                           <option value="2020"> 2020 </option>
                           <option value="2019"> 2019 </option>
                           <option value="2018"> 2018 </option>
                           <option value="2017"> 2017 </option>
                           <option value="2016"> 2016 </option>
                           <option value="2015"> 2015 </option>
                           <option value="2014"> 2014 </option>
                           <option value="2013"> 2013 </option<>
                           <option value="2012"> 2012 </option>
                           <option value="2011"> 2011 </option>
                           <option value="2010"> 2010 </option>
                         </select>
                         <br> <br>
                      <input type="checkbox"  name="voie" value="APP"> <label> APP </label><br>
                      <input type="checkbox"  name="voie" value="Class"> <label> Class </label><br>
                      <br>
                      <select name="libelle">
                        <option value="L3"> L3 </option>
                        <option value="M1"> M1 </option>
                        <option value="M2"> M2 </option>
                      </select>
                    </div>
<br>
                    <input type="submit" class="btn btn-success" value="Exporter">


            </form>
        </div>
    </div>
</div>

</body>
<?php $__env->stopSection(); ?>
</html>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/noufeine/Documents/ProjetMiagiste/resources/views/export.blade.php ENDPATH**/ ?>