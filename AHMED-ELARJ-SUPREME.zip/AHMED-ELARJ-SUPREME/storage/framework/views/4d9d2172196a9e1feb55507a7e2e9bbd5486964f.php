<?php $__env->startSection('contenu'); ?>



<form action='/parcours/<?php echo e($num_etudiant); ?>' method="post">
  <?php echo e(csrf_field()); ?>

  <div class="mx-auto" >
  <div class="card mx-auto" style="width: 85%;" >
    <div class="card-header">
     <img style="width: 5%;"  src="https://image.flaticon.com/icons/png/512/46/46955.png">
    </div>
    <div class="card-body mx-auto">
      <table class="table table-sm">
        <thead>
          <tr>
            <td class="text-center" >Entreprise</td>
            <td class="text-center" >Mission</td>
            <td class="text-center" >Description</td>
            <td class="text-center" >Maitre d'apprentissage</td>
            <td class="text-center" >Date début</td>
            <td class="text-center" >Date fin</td>

          </tr>
        </thead>
        <tbody>
            <tr class='table-hover'>
              <td class="text-center"><textarea name="noms_entreprises" class="form-control" rows="1" required></textarea> </td>
              <td class="text-center"><textarea name="titres" class="form-control" rows="1" required></textarea></td>
              <td class="text-center"><textarea name="descriptions" class="form-control" rows="1" ></textarea></td>
              <td class="text-center"><textarea name="maitres_apprentissages" class="form-control" rows="1" ></textarea></td>
              <td class="text-center"><input name="dates_debuts"  type="date" required></td>
              <td class="text-center"><input name="dates_fins" type="date" required></td>
           </tr>
        </tbody>
      </table>
    </div>
    <div class="card-footer bg-transparent border-success ">
      <ul class="list-group list-group-horizontal " >
        <input type="submit" class="btn btn-outline-info btn-block" value="Ajouter">
      </ul>
    </div>
  </div>
</div>
</form>

















<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/noufeine/Documents/ProjetMiagiste/resources/views/ajout-parcours.blade.php ENDPATH**/ ?>