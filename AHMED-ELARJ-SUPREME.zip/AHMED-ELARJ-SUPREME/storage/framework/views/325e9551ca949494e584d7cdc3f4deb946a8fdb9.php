<?php $__env->startSection('contenu'); ?>




<br>


<!-- Modal -->
<div  class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" ><img src="https://fr.seaicons.com/wp-content/uploads/2017/02/close-icon.png" style="width : 15%;"></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        😬😱 Êtes vous sûr de vouloir supprimer ce.t.s étudiant.s de la base ?
      </div>
      <form action='/modification/<?php echo e($annee); ?>/<?php echo e($promo); ?>/<?php echo e($annee); ?>' method="post">
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Fermer</button>
        <button type="submit" formaction="/accueil" class="btn btn-primary" name="supprimer_etudiants" value="supprimer_etudiants"> Confirmer</button></a>
      </div>
    </div>
  </div>
</div>





  <?php echo e(csrf_field()); ?>

  <div class="card mx-auto" style="width: 70rem;">
    <div class="card-header">
     <img style="width: 5%;"  src="https://image.flaticon.com/icons/png/512/46/46955.png">
     <h4>Liste des Étudiants de la <?php echo e($promo); ?> <?php echo e($voie); ?> <?php echo e($annee); ?></h4>
     <?php if($errors->any()): ?>
     <small class="form-text text-danger text-center"> <?php echo e($errors->first()); ?> </small>
     <?php endif; ?>
    </div>
    <div class="card-body ">
      <table class="table table-sm table-hover">
        <thead>
          <tr>
            <td class="text-center" ></td>
            <td class="text-center" >Numéro d'étudiant</td>
            <td class="text-center" >Nom Prénom</td>
            <td class="text-center" >Entreprise</td>
            <td class="text-center" >Mission</td>
            <td class="text-center" >Description</td>
            <td class="text-center" >Maitre d'apprentissage</td>
            <td class="text-center" >Date début</td>
            <td class="text-center" >Date fin</td>
          </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $etudiants_avec_mission; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $etudiant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <tr class='table-hover'>
              <td class="text-center" ><input type="checkbox" name="choix[]" value="<?php echo e($etudiant->id_miagiste); ?>"></td>

              <input type="hidden" name="id_promotion[]" value="<?php echo e($etudiant->id_promotion); ?>">
              <input type="hidden" name="id_mission[]" value="<?php echo e($etudiant->id_mission); ?>">


              <td class="text-center"><?php echo e($etudiant->id_miagiste); ?></td>
              <td class="text-center"><?php echo e($etudiant->nom); ?> <?php echo e($etudiant->prenom); ?></td>
              <td class="text-center"><?php echo e($etudiant->nom_entreprise); ?></td>
              <td class="text-center"><?php echo e($etudiant->titre); ?></td>
              <td class="text-center"><?php echo e($etudiant->description); ?></td>
              <td class="text-center"><?php echo e($etudiant->maitre_apprentissage); ?></td>
              <td class="text-center"><?php echo e($etudiant->date_debut); ?></td>
              <td class="text-center"><?php echo e($etudiant->date_fin); ?></td>
           </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php $__currentLoopData = $etudiants_sans_mission; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $etudiant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <tr class='table-hover'>
              <td class="text-center" ><input type="checkbox" name="choix[]" value="<?php echo e($etudiant->id_miagiste); ?>"></td>
             <td class="text-center"><?php echo e($etudiant->id_miagiste); ?></td>
             <td class="text-center"><?php echo e($etudiant->nom); ?> <?php echo e($etudiant->prenom); ?></td>
             <td></td>
             <td></td>
             <td></td>
             <td></td>
             <td></td>
             <td></td>
           </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
    <div class="card-footer bg-transparent border-success ">
      <ul class="list-group list-group-horizontal " >
        <li class="list-group-item border-0 border-left-0 text-center" style="width: 25%;">
          <input type="submit" class="btn btn-outline-info btn-block" value="Modifier Mission" name="modifier_mission">
        </li>
        <li class="list-group-item border-0 border-left-0 text-center" style="width: 25%;">
          <input type="submit" formaction="/ajout" class="btn btn-outline-info btn-block" value="Ajouter Mission">
        </li>
        <li class="list-group-item border-0 border-left-0 text-center" style="width: 25%;">
          <input type="submit" formaction="/passage"  class="btn btn-outline-info btn-block" value="Passer Classe Sup">
        </li>
        <li  class="list-group-item border-0 border-left-0 text-center" style="width: 25%;">
          <input type="button"  data-toggle="modal" data-target="#exampleModalCenter"  formaction="/passage"  class="btn btn-outline-danger btn-block" value="Supprimer">

        </li>
      </ul>
    </div>
  </div>
</form>




<script>





</script>



















<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/noufeine/Documents/ProjetMiagiste/resources/views/miagistes.blade.php ENDPATH**/ ?>