<?php $__env->startSection('contenu'); ?>
<br>



<form action='/accueil' method="post">
  <?php echo e(csrf_field()); ?>

  <div class="mx-auto" >
  <div class="card mx-auto" style="width: 50%;" >
    <div class="card-header">
     <img style="width: 5%;"  src="https://image.flaticon.com/icons/png/512/46/46955.png">
    </div>
    <div class="card-body mx-auto">
      <table class="table table-sm">
        <thead>
          <tr>
            <td class="text-center" >Diplome</td>
            <td class="text-center" >Numéro d'étudiant</td>
            <td class="text-center" >Nom Prénom</td>
            <td class="text-center" >Promo</td>
            <td class="text-center">Voie</td>
            <td class="text-center" >Année</td>
          </tr>
        </thead>
        <tbody>

          <?php $__currentLoopData = $etudiants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $etudiant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <?php if($etudiant->id_miagiste!=0): ?>

            <tr class='table-hover'>
              <?php if($etudiant->libelle=='M2'): ?>

              <td class="text-center" ><input type="checkbox" name="choix[]" value="<?php echo e($etudiant->id_miagiste); ?>"></td>


              <?php else: ?>
              <td></td>

              <?php endif; ?>


              <td class="text-center"><input type="hidden" name="num_etudiants[]" value="<?php echo e($etudiant->id_miagiste); ?>" ><?php echo e($etudiant->id_miagiste); ?></td>
              <td class="text-center"><?php echo e($etudiant->nom); ?> <?php echo e($etudiant->prenom); ?></textarea> </td>
              <td class="text-center" >
                <select name="promotions[]">
                  <option ><?php echo e($etudiant->libelle); ?></option>
                  <?php if($etudiant->libelle=='L3'): ?>
                  <option >M1</option>
                  <?php elseif($etudiant->libelle=='M1'): ?>
                  <option >M2</option>
                  <?php else: ?>
                  <?php endif; ?>
                </select>
              </td>
              <td class="text-center" >
                <select name="voies[]">
                  <option value="<?php echo e($etudiant->voie); ?>"><?php echo e($etudiant->voie); ?></option>
                  <option >
                    <?php if($etudiant->voie == 'APP'): ?> Class <?php else: ?> APP  <?php endif; ?>
                  </option>
                </select>
              </td>
              <td class="text-center" >
                <select name="annees[]">
                  <option value="<?php echo e($etudiant->annee); ?>"><?php echo e($etudiant->annee); ?></option>
                  <option >
                    <?php echo e($etudiant->annee +1); ?>

                  </option>
                </select>
              </td>
           </tr>
           <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>

    </div>
    <div class="card-footer bg-transparent border-success ">
      <ul class="list-group list-group-horizontal " >
        <li class="list-group-item border-0 border-left-0 text-center" style="width: 50%;">
        <input type="submit" class="btn btn-outline-info btn-block" value="Diplome" name="diplome">
        </li>
        <li class="list-group-item border-0 border-left-0 text-center" style="width: 50%;">
          <input type="submit" class="btn btn-outline-info btn-block" value="Passer" name="passer">
        </li>
      </ul>
    </div>
  </div>
</div>
</form>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/noufeine/Documents/ProjetMiagiste/resources/views/passage.blade.php ENDPATH**/ ?>