<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"
    integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

    <link rel="stylesheet" href="bootstrap.min.css">

    <!-- Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"
    integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"
    integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"
    integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>


    <style>
    /*On definie le sidenav avec une transition de 0.5s */
      .sidenav {
        height: 100%;
        width: 0;
        position: fixed;
        top: 0;
        left: 0;
        background-color: white;
        overflow-x: hidden;
        transition: 0.5s;
        padding-top: 60px;

      }

      .sidenav a {
        padding: 8px 8px 8px 32px;
        text-decoration: none;
        display: block;
      }

      .sidenav a:hover {
        color: #f1f1f1;
      }

      .sidenav .closebtn {
        position: absolute;
        top: 0;
        right: 25px;
        font-size: 36px;
        margin-left: 50px;
      }

      #main {
        transition: margin-left .5s;
      }

      .dropdown:hover .dropdown-menu
      {
        display:block;
      }
      .dropdown-menu{
        width: 200%;
      }

      .dropdown-toggle::after {
    display: none;
    }

    body {
        background-image: url("/images/nanterrepng.jpg");
        background-size: 2100px;
        background-attachment: fixed;
}


    </style>

  </head>

  <body class="float-none ">

    <div id="main" >
      <!--La barre de navigation du haut-->
      <nav  class="navbar navbar-expand-lg navbar-light bg-light">
          <span class="navbar-toggler-icon" style='cursor:pointer;' onclick="openNav()"></span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          <a href="/accueil">
            <img src="https://upload.wikimedia.org/wikipedia/commons/a/a3/Logo_Université_Paris-Nanterre.svg" style="width:150px">
          </a>
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            <div class="dropdown mr-auto">
              <input class="dropdown-toggle form-control" id="recherche" type="search"
              placeholder="Numéro, nom ou prénom"  data-toggle="dropdown"
              aria-haspopup="true" aria-expanded="false" name="recherche" onkeyup="myFunction()"
              style="width:200%" >

              <div class="dropdown-menu " id ="contenu"></div>

            </div>
            <div class="dropdown ml-auto">
              <a href="/ajout-etudiant">
              Ajouter un etudiant
              <img src="https://cdn4.iconfinder.com/data/icons/pretty_office_3/256/Add-Male-User.png" style="width:30px">
            </a>

              &nbsp;&nbsp;&nbsp;&nbsp;
              <a href="/import-excel">
              Importer
              <img src="https://fr.seaicons.com/wp-content/uploads/2015/11/import-icon1.png" style="width:30px">
            </a>
              &nbsp;&nbsp;&nbsp;&nbsp;

              <a href="/exportView">
                Exporter
                <img src="https://cdn3.iconfinder.com/data/icons/bold-blue-glyphs-free-samples/32/89_Import_Down_Download_Save-512.png" style="width:30px"></a>
              <a>

            <div>
      </nav>

  <div id="mySidenav" class="sidenav">
      <a href="#" class="closebtn" onclick="closeNav()" >&times;</a>
        <?php
        //echo "string : ".$premiere_annee;
        if(!empty($premiere_annee)){
        for ($date=date('Y')-1; $date >= $premiere_annee ; $date--) {
          echo "
          <a data-toggle='collapse' href='#collapse".$date."' class='text-dark' onmouseover='f1(this)' onmouseout='f2(this)' style='border-radius: 1px 50px 50px 1px;'>
              ".$date."
          </a>
          <div class='collapse' id='collapse".$date."' >
                  <a data-toggle='collapse' href='#collapse".$date."M2' class='text-dark' onmouseover='f1(this)' onmouseout='f2(this)' style='border-radius: 1px 50px 50px 1px;'>
                    &nbsp;&nbsp;&nbsp;M2
                  </a>
                  <div class='collapse' id='collapse".$date."M2' >
                    <a href='/miagistes/".$date."/M2/APP' class='text-dark' onmouseover='f1(this)' onmouseout='f2(this)' style='border-radius: 1px 50px 50px 1px;'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;APP</a>
                    <a href='/miagistes/".$date."/M2/Class' class='text-dark' onmouseover='f1(this)' onmouseout='f2(this)' style='border-radius: 1px 50px 50px 1px;'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Class</a>
                  </div>
                  <a  data-toggle='collapse' href='#collapse".$date."M1' class='text-dark' onmouseover='f1(this)' onmouseout='f2(this)' style='border-radius: 1px 50px 50px 1px;'>
                    &nbsp;&nbsp;&nbsp;M1
                  </a>
                  <div class='collapse' id='collapse".$date."M1' >
                    <a href='/miagistes/".$date."/M1/APP' class='text-dark' onmouseover='f1(this)' onmouseout='f2(this)' style='border-radius: 1px 50px 50px 1px;'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;APP</a>
                    <a href='/miagistes/".$date."/M1/Class' class='text-dark' onmouseover='f1(this)' onmouseout='f2(this)' style='border-radius: 1px 50px 50px 1px;'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Class</a>
                  </div>
                  <a data-toggle='collapse'  href='#collapse".$date."L3' class='text-dark' onmouseover='f1(this)' onmouseout='f2(this)' style='border-radius: 1px 50px 50px 1px;'>
                    &nbsp;&nbsp;&nbsp;L3
                  </a>
                  <div class='collapse' id='collapse".$date."L3' >
                      <a href='/miagistes/".$date."/L3/APP' class='text-dark' onmouseover='f1(this)' onmouseout='f2(this)' style='border-radius: 1px 50px 50px 1px;'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;APP</a>
                      <a href='/miagistes/".$date."/L3/Class' class='text-dark' onmouseover='f1(this)' onmouseout='f2(this)' style='border-radius: 1px 50px 50px 1px;'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Class</a>
                  </div>
            </div>
          ";
        }
      }
        ?>

  </div>

  <br>



  <?php echo $__env->yieldContent('contenu'); ?>






</div>

<script>
var i=0;
function f1(id){
  id.style.backgroundColor = "#F1F3F4";
}

function f2(id){
  id.style.backgroundColor = "white";
}

function down(){
  if(i==0){
    document.getElementById("M2019").innerHTML = '&#x25BC;';
    i=1;
  }
  else{
    document.getElementById("M2019").innerHTML = '&#x25BA;';
    i=0;

  }
}

function openNav() {
  document.getElementById("mySidenav").style.width = "250px";
  document.getElementById("main").style.marginLeft = "250px";
}

function closeNav() {
  document.getElementById("mySidenav").style.width = "0";
  document.getElementById("main").style.marginLeft= "0";
}
</script>








  </body>


  <script type="text/javascript">
  var miagiste = <?php echo json_encode($miagiste, 15, 512) ?>;




  function myFunction() {
    document.getElementById("contenu").innerHTML="";
    var val = document.getElementById("recherche").value;
    var contenu = "";

    if(val!=""){
      for(var i=0; i<miagiste.length; i++){

        var nom=miagiste[i].nom;
        var prenom=miagiste[i].prenom;
        var num_etudiant=miagiste[i].id_miagiste;

        //indice du la premiere occurence de val
        //renvoie -1 si l'occurence n'existe pas
        var indice=((num_etudiant+" "+nom+" "+prenom).toUpperCase()).indexOf(val.toUpperCase());

        //on verifie si le mot tappé est bien le debut d'un nom/prenom/numéro etudiant
        if(indice==0 || indice==(num_etudiant+" ").length || indice==(num_etudiant+" "+nom+" ").length){
          //dans div1 on copie la premiere partie du mot sans gras
          var div1 =(num_etudiant+" "+nom+" "+prenom).slice(0, indice);

          //dans div2 on copie la 2eme partie du mot avec gras
          var div2 =(num_etudiant+" "+nom+" "+prenom).slice(indice, indice+val.length);

          //dans div3 on copie la 3eme partie du mot sans gras
          var div3 =(num_etudiant+" "+nom+" "+prenom).slice(indice+val.length, (num_etudiant+" "+nom+" "+prenom).length);

          document.getElementById("contenu").innerHTML=contenu+"<a href='/informations/"+num_etudiant+"'> "+div1+"<b>"+div2+"</b>"+div3+"</a><br>";
          contenu = document.getElementById("contenu").innerHTML;
        }

      }
    }
  }

  var premiere_annee = <?php echo e($premiere_annee); ?>;

  console.log("hhh : "+premiere_annee);
  </script>


</html>
<?php /**PATH /Users/noufeine/Documents/ProjetMiagiste/resources/views/layout.blade.php ENDPATH**/ ?>