<?php $__env->startSection('contenu'); ?>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/noufeine/Documents/ProjetMiagiste/resources/views/accueil.blade.php ENDPATH**/ ?>