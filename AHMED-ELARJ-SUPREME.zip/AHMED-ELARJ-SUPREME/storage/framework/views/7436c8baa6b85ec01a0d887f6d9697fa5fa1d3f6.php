<!DOCTYPE html>
<html>
<head>
    <title>Importation Miagiste</title>
</head>






<?php $__env->startSection('contenu'); ?>


<div class="container">
    <div class="card mt-4">
        <div class="card-header">
            Importation Miagiste
        </div>
            <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
   <?php if($message = Session::get('success')): ?>
   <div class="alert alert-success alert-block">
    <button type="button" class="close" data-dismiss="alert">×</button>
           <strong><?php echo e($message); ?></strong>
   </div>
   <?php endif; ?>
        <div class="card-body">
            <form action="<?php echo e(url('import-excel')); ?>" method="POST" name="importform" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <input type="file" name="import_file" class="form-control">
                <br>
                <button class="btn btn-success">Import Fichier</button>
            </form>
        </div>
    </div>
    <div class="panel panel-default">
    <div class="panel-heading">
     <h3 class="panel-title">💻 Miagistes de Nanterre </h3>
    </div>
    <div class="panel-body">
     <div class="table-responsive">
      <table class="table table-bordered table-striped">
        <tr>
        <th>Numéro</th>
        <th>Nom</th>
        <th>Prénom</th>
        <th>Promo</th>
        <th>Voie</th>
       </tr>
       <?php $__currentLoopData = $miagiste; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       <tr>
        <td><?php echo e($row->id_miagiste); ?></td>
        <td><?php echo e($row->nom); ?></td>
        <td><?php echo e($row->prenom); ?></td>
        <td><?php echo e($row->libelle); ?></td>
        <td><?php echo e($row->voie); ?></td>
       </tr>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </table>
     </div>
    </div>
</div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/noufeine/Documents/ProjetMiagiste/resources/views/import_excel/index.blade.php ENDPATH**/ ?>