


<?php $__env->startSection('contenu'); ?>
<br>



<form action='/accueil' method="post">
  <?php echo e(csrf_field()); ?>

  <div class="mx-auto" >
  <div class="card mx-auto" style="width: 85%;" >
    <div class="card-header">
     <img style="width: 5%;"  src="https://image.flaticon.com/icons/png/512/46/46955.png">
    </div>
    <div class="card-body mx-auto">
      <table class="table table-sm">
        <thead>
          <tr>
            <td class="text-center" style="width: 12.5%;">Numéro d'étudiant</td>
            <td class="text-center" style="width: 12.5%;">Nom Prénom</td>

            <td class="text-center" style="width: 12.5%;">Entreprise</td>
            <td class="text-center" style="width: 12.5%;">Mission</td>
            <td class="text-center" style="width: 12.5%;">Description</td>
            <td class="text-center" style="width: 12.5%;">Maitre d'apprentissage</td>
            <td class="text-center" >Date début</td>
            <td class="text-center" >Date fin</td>

          </tr>
        </thead>
        <tbody>


         <?php $__currentLoopData = $nom; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class='table-hover'>

              <td class="text-center"><input type="hidden" name="num_etudiants[]" value="<?php echo e($n->id_miagiste); ?>"><?php echo e($n->id_miagiste); ?></td>
              <td class="text-center"> <?php echo e($n->nom); ?> <?php echo e($n->prenom); ?></td>

              <td class="text-center">
                <input list="noms_entreprises" name="noms_entreprises[]" required>
                  <datalist id="noms_entreprises">
                    <?php $__currentLoopData = $liste_entreprises; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entreprise): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($entreprise->nom_entreprise); ?>">
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </datalist>
                </td>


                <td class="text-center">
                  <input list="titres" name="titres[]" required>
                    <datalist id="titres">
                      <?php $__currentLoopData = $liste_missions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($mission->titre); ?>">
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </datalist>
                  </td>

<!--
              <td class="text-center"><textarea name="titres[]" class="form-control" rows="1" value="" required=""></textarea></td>
-->
              <td class="text-center"><textarea name="descriptions[]" class="form-control" rows="1" value=""></textarea></td>
              <td class="text-center"><textarea name="maitres_apprentissages_avec_mission[]" class="form-control" rows="1" value="" ></textarea></td>
              <td class="text-center"><input name="dates_debuts[]"  type="date" value="" required></td>
              <td class="text-center"><input name="dates_fins[]" type="date" value="" required></td>
              <td class="text-center invisible"><input  type="hidden" name="id_missions[]" value="" ></td>
              <td class="text-center invisible"><input type="hidden" name="id_promotions[]" value="" ></td>

           </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>
      </table>
    </div>
    <div class="card-footer bg-transparent border-success ">
      <ul class="list-group list-group-horizontal " >
        <input type="submit" class="btn btn-outline-info btn-block" value="Ajouter" name="ajouter">
      </ul>
    </div>
  </div>
</div>
</form>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/noufeine/Documents/ProjetMiagiste/resources/views/ajout.blade.php ENDPATH**/ ?>