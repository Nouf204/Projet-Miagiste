<!DOCTYPE html>
<html>
  <head>
    <title>Recherche par nom</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bulma@0.8.0/css/bulma.css" />
  </head>

  <body>
    <!-- Main container -->
<nav class="level navbar">
  <?php echo e(csrf_field ()); ?>


  <!-- Left side -->

  <div class="dropdown is-hoverable navbar-end ">
    <div class="dropdown-trigger">
        <input aria-haspopup="true" aria-controls="dropdown-menu4" class="input" type="text"
        placeholder="nom-prenom-num" id="nom" name="nom" onkeyup="myFunction()" >
    </div>
    <div class="dropdown-menu " id="dropdown-menu4" role="menu">
      <div class="dropdown-content">
        <div class="dropdown-item"  id="demo">
        </div>
      </div>
    </div>
  </div>

</nav>




<div class="has-text-centered">
  je ssuis teleme,tkbdLICBSHGlizefdsjkxhuzfgdCHBCDKFDJHFDJFJHSX,CNkjfkdvkjfrk,ck,krjfirfhrifnck<br>
  je ssuis teleme,tkbdLICBSHGlizefdsjkxhuzfgdCHBCDKFDJHFDJFJHSX,CNkjfkdvkjfrk,ck,krjfirfhrifnck<br>
  je ssuis teleme,tkbdLICBSHGlizefdsjkxhuzfgdCHBCDKFDJHFDJFJHSX,CNkjfkdvkjfrk,ck,krjfirfhrifnck<br>
  je ssuis teleme,tkbdLICBSHGlizefdsjkxhuzfgdCHBCDKFDJHFDJFJHSX,CNkjfkdvkjfrk,ck,krjfirfhrifnck<br>
  je ssuis teleme,tkbdLICBSHGlizefdsjkxhuzfgdCHBCDKFDJHFDJFJHSX,CNkjfkdvkjfrk,ck,krjfirfhrifnck<br>
  je ssuis teleme,tkbdLICBSHGlizefdsjkxhuzfgdCHBCDKFDJHFDJFJHSX,CNkjfkdvkjfrk,ck,krjfirfhrifnck<br>
</div><br>

  <script type="text/javascript">
  var miagiste = <?php echo json_encode($miagiste, 15, 512) ?>;


  console.log(miagiste);



  function myFunction() {
    document.getElementById("demo").innerHTML="";
    var val = document.getElementById("nom").value;
    var contenu = "";

    if(val!=""){
      for(var i=0; i<miagiste.length; i++){

        var nom=miagiste[i].nom;
        var prenom=miagiste[i].prenom;
        var indice=((nom+" "+prenom).toUpperCase()).indexOf(val.toUpperCase());

        if(indice!=-1){
          var div1 =(nom+" "+prenom).slice(0, indice);
          var div2 =(nom+" "+prenom).slice(indice, indice+val.length);
          var div3 =(nom+" "+prenom).slice(indice+val.length, (nom+" "+prenom).length);

          document.getElementById("demo").innerHTML=contenu+" "+div1+"<b>"+div2+"</b>"+div3+"<br>";
          contenu = document.getElementById("demo").innerHTML;
        }

      }
    }
    console.log(contenu);
  }
  </script>



  </body>
</html>
<?php /**PATH /Users/noufeine/Documents/ProjetMiagiste/resources/views/recherche/nom.blade.php ENDPATH**/ ?>