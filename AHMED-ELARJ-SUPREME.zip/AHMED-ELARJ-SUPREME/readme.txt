MEMBRES DU GROUPE 
Noufeine AHMED Aniss ELARJ  Chelson SUPREME 



ENVIRONNEMENT UTILISES 
Laravel 6 pour le coté PHP  Bootstrapp 4 pour le coté CSS Phpmyadmin pour la BD 



LANCEMENT DU PROJET
Installation de Laravel : https://laravel.com/docs/5.8/installation
Installation de maatwebsite (pour l’importation et exportation)  par la commande (sur le terminal) : composer require maatwebsite/excel
Lancement du projet par la commande (sur le terminal) : php artisan serve



CREATION DE LA BD
Importer la BD (bdmiagiste.sql) dans PHPMyAdmin.
IMPORTATION 
Importer la feuille (import_excel.xls) dans Le projet (dans la page import-excel.php) pour remplir la BD.



