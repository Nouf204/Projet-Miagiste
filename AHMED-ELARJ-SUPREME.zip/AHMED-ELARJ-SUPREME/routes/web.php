<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});



Route::POST('/modification/{annee}/{promo}/{voie}', function () {



if (empty((request('choix'))))return Redirect::back()->withErrors('⚠️ Veuillez cocher sur un étudiant');

$miagiste=DB::table('Miagiste')->get();
$premiere_annee=DB::table('Promotion')->orderBy('annee','asc')->take(1)->value('annee');

$etudiants_avec_mission=DB::table('Miagiste')
                ->whereIn('Miagiste.id_miagiste',request('choix'))
                ->join('Effectue','Effectue.id_miagiste','=','Miagiste.id_miagiste')
                ->join('Mission','Mission.id_mission','=','Effectue.id_mission')
                ->join('Entreprise','Entreprise.id_entreprise','=','Mission.id_entreprise')
                ->join('Est_de_passage','Est_de_passage.id_miagiste','=','Miagiste.id_miagiste')
                ->join('Promotion','Promotion.id_promotion','=','Est_de_passage.id_promotion')
                ->whereIn('Est_de_passage.id_promotion',request('id_promotion'))
                ->whereIn('Effectue.id_mission',request('id_mission'))
                ->get();

$etudiants_sans_mission=DB::table('Miagiste')
                ->join('Est_de_passage','Est_de_passage.id_miagiste','=','Miagiste.id_miagiste')
                ->join('Promotion','Promotion.id_promotion','=','Est_de_passage.id_promotion')
                ->whereNotIn('Miagiste.id_miagiste', function($q){
                    $q->select('Effectue.id_miagiste')->from('Effectue');
                })
                ->whereIn('Miagiste.id_miagiste',request('choix'))
                ->get();

$annee=request('annee');
$promo=request('promo');
$voie=request('voie');

$premiere_annee=DB::table('Promotion')->orderBy('annee','asc')->take(1)->value('annee');

  $liste_entreprises=DB::table('Entreprise')->get();
return view('modification',compact('premiere_annee','annee','promo','voie','miagiste','premiere_annee','etudiants_avec_mission','etudiants_sans_mission','liste_entreprises'));
});




Route :: get('/ajout-parcours/{num_etudiant}',function(){

  $miagiste=DB::table('Miagiste')->get();
  $premiere_annee=DB::table('Promotion')->orderBy('annee','asc')->take(1)->value('annee');
  $num_etudiant=request('num_etudiant');
  return view('ajout-parcours',compact('premiere_annee','miagiste','num_etudiant'));

});




Route :: POST('parcours/{num_etudiant}',function(){

  //on l'ajoute dans une promotion
  if(request('annees')!="" && request('promotions')!="" && request('voies')!=""){

  $id_promo=DB::table('Promotion')
            ->where('annee',request('annees'))
            ->where('libelle',request('promotions'))
            ->where('voie',request('voies'))
            ->take(1)
            ->value('id_promotion');

  DB::table('Est_de_passage')
      ->updateOrInsert(['id_promotion' => $id_promo, 'id_miagiste' => request('num_etudiant')],
      ['id_promotion' => $id_promo, 'id_miagiste' => request('num_etudiant')]);
  }

  //on l'ajoute dans une entreprise
  if(request('noms_entreprises')!="" && request('titres')!="" && request('dates_debuts')!=""){



    DB::table('Entreprise')
        ->updateOrInsert(['nom_entreprise' => request('noms_entreprises')],
        ['nom_entreprise' => request('noms_entreprises')]);


    $id_entr=DB::table('Entreprise')
            ->where('nom_entreprise',request('noms_entreprises'))
            ->take(1)
            ->value('id_entreprise');

    DB::table('Mission')
        ->updateOrInsert(['titre' => request('titres'),'date_debut' => request('dates_debuts'), 'id_entreprise' => $id_entr],
        [
        'date_debut' => request('dates_debuts'),
        'id_entreprise' => $id_entr,
        'date_fin' => request('dates_fins'),
        'description' => request('descriptions'),
        'maitre_apprentissage' => request('maitres_apprentissages'),
      ]);


    $id_mission=DB::table('Mission')
            ->where('titre',request('titres'))
            ->where('date_debut' ,request('dates_debuts'))
            ->where('id_entreprise' , $id_entr)
            ->take(1)
            ->value('id_mission');


    DB::table('Effectue')
      ->updateOrInsert(['id_miagiste' => request('num_etudiant'), 'id_mission' => $id_mission],
                ['id_miagiste' => request('num_etudiant'), 'id_mission' => $id_mission]);
  }


  $parcours=DB::table('Miagiste')
            ->where('Miagiste.id_miagiste',request('num_etudiant'))
            ->join('Est_de_passage', 'Miagiste.id_miagiste', '=', 'Est_de_passage.id_miagiste')
            ->join('Promotion', 'Est_de_passage.id_promotion', '=', 'Promotion.id_promotion')
            ->orderBy('Promotion.annee', 'desc')
            ->get();

  $miagiste=DB::table('Miagiste')->get();
  $premiere_annee=DB::table('Promotion')->orderBy('annee','asc')->take(1)->value('annee');
  $num_etudiant=request('num_etudiant');
  return view('parcours',compact('premiere_annee','miagiste','num_etudiant','parcours'));
});

Route::get('/layout', function(){return view('layout');});

Route::get('/bonjour/{nom}', function(){
  return view('bonjour',['prenom'=>request('nom')]);
});

Route::get('/informations/{num_etudiant}', function(){
        //on recupere les donnee pour les envoyer dans la page layout
        //affin qu'ils puissent etre afficher
        $miagiste=DB::table('Miagiste')->get();
        $premiere_annee=DB::table('Promotion')->orderBy('annee','asc')->take(1)->value('annee');

        //on recupere l'annee du dernier M2
        $annee_diplome=DB::table('Promotion')
                      ->join('Est_de_passage','Est_de_passage.id_promotion','=','Promotion.id_promotion')
                      ->where('Est_de_passage.id_miagiste',request('num_etudiant'))
                      ->where('libelle','M2')
                      ->orderBy('Promotion.annee', 'desc')
                      ->take(1)
                      ->value('Promotion.annee');

        if(empty($annee_diplome)) $annee_diplome=0;

        $num_etudiant=request('num_etudiant');


        return view('informations',compact('premiere_annee','miagiste','num_etudiant','annee_diplome'));
});



Route :: get('/modifier/{num_etudiant}',function(){

  $miagiste=DB::table('Miagiste')->get();
  $premiere_annee=DB::table('Promotion')->orderBy('annee','asc')->take(1)->value('annee');
  $num_etudiant=request('num_etudiant');
  return view('modifier',compact('premiere_annee','miagiste','num_etudiant'));

});



Route::post('/informations/{num_etudiant}',function(){

  request()->validate([
    'nom'=>['alpha'],
    'prenom'=>['alpha'],
  'tel'=>['numeric','nullable','digits_between:10,10','starts_with:0'],
  'mail_externe'=>['nullable','email']]);

  App\Miagiste::updateOrInsert([
  'id_miagiste' =>request('num_etudiant')],
  ['nom'=>request('nom'),
  'prenom'=>request('prenom'),
  'mail_externe' => request('mail_externe'),
  'mail_interne' => request('mail_interne'),
  'adresse' => request('adresse'),
  'tel' => request('tel'),
  'date_naissance' => request('date_naissance'),]);

  $miagiste=DB::table('Miagiste')->get();
  $premiere_annee=DB::table('Promotion')->orderBy('annee','asc')->take(1)->value('annee');
  $num_etudiant=request('num_etudiant');

  $annee_diplome=DB::table('Promotion')
                ->join('Est_de_passage','Est_de_passage.id_promotion','=','Promotion.id_promotion')
                ->where('Est_de_passage.id_miagiste',request('num_etudiant'))
                ->where('libelle','M2')
                ->orderBy('Promotion.annee', 'desc')
                ->take(1)
                ->value('Promotion.annee');

  if(empty($annee_diplome)) $annee_diplome=0;

  return view('informations',compact('premiere_annee','miagiste','num_etudiant','annee_diplome'));
});

Route :: get('/parcours/{num_etudiant}',function(){


  $derniere_annee=DB::table('Miagiste')
            ->where('Miagiste.id_miagiste',request('num_etudiant'))
            ->join('Est_de_passage', 'Miagiste.id_miagiste', '=', 'Est_de_passage.id_miagiste')
            ->join('Promotion', 'Est_de_passage.id_promotion', '=', 'Promotion.id_promotion')
            ->orderBy('Promotion.annee', 'desc')
            ->take(1)
            ->value('Promotion.annee');


  $parcours=DB::table('Miagiste')
            ->where('Miagiste.id_miagiste',request('num_etudiant'))
            ->join('Est_de_passage', 'Miagiste.id_miagiste', '=', 'Est_de_passage.id_miagiste')
            ->join('Promotion', 'Est_de_passage.id_promotion', '=', 'Promotion.id_promotion')
            ->join('Effectue', 'Miagiste.id_miagiste', '=', 'Effectue.id_miagiste')
            ->join('Mission', 'Mission.id_mission', '=', 'Effectue.id_mission')
            ->join('Entreprise', 'Entreprise.id_entreprise', '=', 'Mission.id_entreprise')
            ->orderBy('Promotion.annee', 'desc')
            ->get();

  $carriere=DB::table('Miagiste')
            ->where('Miagiste.id_miagiste',request('num_etudiant'))
            ->where('diplome',1)
            ->join('Effectue', 'Miagiste.id_miagiste', '=', 'Effectue.id_miagiste')
            ->join('Mission', 'Mission.id_mission', '=', 'Effectue.id_mission')
            ->join('Entreprise', 'Entreprise.id_entreprise', '=', 'Mission.id_entreprise')
            ->get();

if(count($parcours)==0 && count($carriere)==0){
  return Redirect::back()->withErrors('⚠️ Cet étudiant n\'a pas de parcours professionnel');
};


  $miagiste=DB::table('Miagiste')->get();
  $premiere_annee=DB::table('Promotion')->orderBy('annee','asc')->take(1)->value('annee');
  $num_etudiant=request('num_etudiant');
  return view('parcours',compact('derniere_annee','premiere_annee','miagiste','num_etudiant','parcours','carriere'));

});


Route :: POST('/parcours/{num_etudiant}',function(){

  DB::table('Entreprise')
    ->updateOrInsert(
      ['nom_entreprise' =>request('noms_entreprises')],
      ['nom_entreprise' => request('noms_entreprises')]);

  $id_entr=DB::table('Entreprise')
    ->where('nom_entreprise', request('noms_entreprises'))
    ->take(1)
    ->value('id_entreprise');

  DB::table('Mission')
    ->insert(
    ['titre' => request('titres'),
    'description' => request('descriptions'),
    'maitre_apprentissage' => request('maitres_apprentissages'),
    'date_debut' => request('dates_debuts'),
    'date_fin' => request('dates_fins'),
    'id_entreprise'=>$id_entr
  ]);

  $id_mission=DB::table('Mission')
    ->where('titre', request('titres'))
    ->where('id_entreprise', $id_entr)
    ->where('date_debut', request('dates_debuts'))
    ->where('date_fin', request('dates_fins'))
    ->take(1)
    ->value('id_mission');


    DB::table('Effectue')
      ->updateOrInsert(
        ['id_mission' =>$id_mission,
        'id_miagiste' =>request('num_etudiant')],
        ['id_mission' =>$id_mission,
        'id_miagiste' =>request('num_etudiant')]);


//Affichage
  $derniere_annee=DB::table('Miagiste')
            ->where('Miagiste.id_miagiste',request('num_etudiant'))
            ->join('Est_de_passage', 'Miagiste.id_miagiste', '=', 'Est_de_passage.id_miagiste')
            ->join('Promotion', 'Est_de_passage.id_promotion', '=', 'Promotion.id_promotion')
            ->orderBy('Promotion.annee', 'desc')
            ->take(1)
            ->value('Promotion.annee');

  $parcours=DB::table('Miagiste')
            ->where('Miagiste.id_miagiste',request('num_etudiant'))
            ->join('Est_de_passage', 'Miagiste.id_miagiste', '=', 'Est_de_passage.id_miagiste')
            ->join('Promotion', 'Est_de_passage.id_promotion', '=', 'Promotion.id_promotion')
            ->join('Effectue', 'Miagiste.id_miagiste', '=', 'Effectue.id_miagiste')
            ->join('Mission', 'Mission.id_mission', '=', 'Effectue.id_mission')
            ->join('Entreprise', 'Entreprise.id_entreprise', '=', 'Mission.id_entreprise')
            ->orderBy('Promotion.annee', 'desc')
            ->get();

  $carriere=DB::table('Miagiste')
            ->where('Miagiste.id_miagiste',request('num_etudiant'))
            ->where('diplome',1)
            ->join('Effectue', 'Miagiste.id_miagiste', '=', 'Effectue.id_miagiste')
            ->join('Mission', 'Mission.id_mission', '=', 'Effectue.id_mission')
            ->join('Entreprise', 'Entreprise.id_entreprise', '=', 'Mission.id_entreprise')
            ->get();

  $miagiste=DB::table('Miagiste')->get();
  $premiere_annee=DB::table('Promotion')->orderBy('annee','asc')->take(1)->value('annee');
  $num_etudiant=request('num_etudiant');
  return view('parcours',compact('derniere_annee','premiere_annee','miagiste','num_etudiant','parcours','carriere'));

});


Route::get('/accueil', function(){
  $miagiste=DB::table('Miagiste')->get();
  $premiere_annee=DB::table('Promotion')->orderBy('annee','asc')->take(1)->value('annee');

  return view('accueil',compact('miagiste','premiere_annee'));});


Route::post('/accueil', function(){

  //modifiaction d'une Mission
  if(!empty(request('modification'))){
    //On met à jour la table Miagiste avec seulement le nom
    //var_dump(request('num_etudiants_avec_mission'));

    // Si l'etudiant a une mission
    if (!empty(request('id_missions_avec_mission'))){
      for ($i = 0; $i <count(request('id_missions_avec_mission'));$i++) {

        //on recupere l'identifiant de la promortion
        $id_promo=DB::table('Promotion')
                      ->where('annee', request('annees_avec_mission')[$i])
                      ->where('libelle', request('promotions_avec_mission')[$i])
                      ->where('voie', request('voies_avec_mission')[$i])
                      ->take(1)
                      ->value('id_promotion');

        //on met à jour la BD en remplacant l'ancien identifiant par le nouveau
        DB::table('Est_de_passage')
          ->updateOrInsert(['id_promotion' => request('id_promotions_avec_mission')[$i],
          'id_miagiste' => request('num_etudiants_avec_mission')[$i]],[

          'id_promotion' => $id_promo
          ]);

        //on recupere ensuite l'identifiant de l'entreprise
        $id_entr=DB::table('Mission')
                      ->where('id_mission', request('id_missions_avec_mission')[$i])
                      ->take(1)
                      ->value('id_entreprise');

        //On met à jour le nom de l'entreprise
        DB::table('Entreprise')
        ->updateOrInsert(['id_entreprise' => $id_entr],
        ['nom_entreprise'=>request('noms_entreprises_avec_mission')[$i]]
      );

        //on recupere ensuite le nom de l'entreprise
        $nom_etr=DB::table('Entreprise')
                      ->where('id_entreprise', $id_entr)
                      ->take(1)
                      ->value('nom_entreprise');

        //on met à jour le nom de l'entreprise


        //et enfin on met à jour la mission
        DB::table('Mission')
          ->updateOrInsert(['id_mission' => request('id_missions_avec_mission')[$i]],
          ['titre' => request('titres_avec_mission')[$i],
          'description' => request('descriptions_avec_mission')[$i],
          'maitre_apprentissage' => request('maitres_apprentissages_avec_mission')[$i],
          'date_debut' => request('dates_debuts_avec_mission')[$i],
          'date_fin' => request('dates_fins_avec_mission')[$i]
        ]);

      }
    }

    //si l'etudiant n'a pas de Mission
    if (!empty(request('num_etudiants_sans_mission'))){
      for ($i = 0; $i <count(request('num_etudiants_sans_mission'));$i++) {
        //on recupere l'identifiant de la promortion
        $id_promo=DB::table('Promotion')
                      ->where('annee', request('annees_sans_mission')[$i])
                      ->where('libelle', request('promotions_sans_mission')[$i])
                      ->where('voie', request('voies_sans_mission')[$i])
                      ->take(1)
                      ->value('id_promotion');

        //on met à jour la BD en remplacant l'ancien identifiant par le nouveau
        DB::table('Est_de_passage')
          ->updateOrInsert(['id_promotion' => request('id_promotions_sans_mission')[$i],
          'id_miagiste' => request('num_etudiants_sans_mission')[$i]],[
          'id_promotion' => $id_promo
          ]);

        //on insert(ou pas) l'entreprise
        DB::table('Entreprise')
          ->updateOrInsert(
            ['nom_entreprise' =>request('noms_entreprises_sans_mission')[$i]],
            ['nom_entreprise' => request('noms_entreprises_sans_mission')[$i]]);

        //on recupere l'identifiant de cet entreprise
        $id_entr=DB::table('Entreprise')
          ->where('nom_entreprise', request('noms_entreprises_sans_mission')[$i])
          ->take(1)
          ->value('id_entreprise');

        //on cree ensuite la mission
        DB::table('Mission')
          ->insert(['titre' => request('titres_sans_mission')[$i],
          'description' => request('descriptions_sans_mission')[$i],
          'maitre_apprentissage' => request('maitres_apprentissages_sans_mission')[$i],
          'date_debut' => request('dates_debuts_sans_mission')[$i],
          'date_fin' => request('dates_fins_sans_mission')[$i],
          'id_entreprise'=>$id_entr
        ]);

        //on recupere l'identifiant de cette Mission
        $id_m=DB::table('Mission')
              ->where('id_entreprise',$id_entr)
              ->take(1)
              ->value('id_mission');

        //on ajoute cet identifant dans la tabel effectue
        DB::table('Effectue')
        ->insert(
          ['id_miagiste' => request('num_etudiants_sans_mission')[$i],
        'id_mission'=> $id_m]);

      }
    }
  }



  //Ajouter eturdiant
  if(!empty(request('ajouter_etudiant'))){

    $id_m=DB::table('Miagiste')
      ->where('id_miagiste', request('id_miagiste'))
      ->take(1)
      ->value('id_miagiste');


    if(!empty($id_m)){
      return Redirect::back()->withErrors('⚠️ L\'etudiant existe déjà');
    }

    else{

    request()->validate([
      'id_miagiste'=>['numeric','required'],
      'nom'=>['alpha','required'],
      'prenom'=>['alpha','required'],
    'tel'=>['numeric','nullable','digits_between:10,10','starts_with:0'],
    'mail_externe'=>['nullable','email']]);

    DB::table('Miagiste')
      ->updateOrInsert(
        ['id_miagiste' =>request('id_miagiste')],
        ['id_miagiste' => request('id_miagiste'),
        'nom'=>request('nom'),
        'prenom'=>request('prenom'),
        'mail_externe'=>request('mail_externe'),
        'date_naissance'=>request('date_naissance'),
        'adresse'=>request('adresse'),
        'tel'=>request('tel')]);

      $id_promo=DB::table('Promotion')
        ->where('annee', request('annee'))
        ->where('voie', request('voie'))
        ->where('libelle', request('promotion'))
        ->take(1)
        ->value('id_promotion');

      DB::table('Est_de_passage')
        ->updateOrInsert(
          ['id_miagiste' =>request('id_miagiste'),
          'id_promotion' => request('id_promotion')],
          ['id_miagiste' =>request('id_miagiste'),
          'id_promotion' => $id_promo]);

        }
  }




  //Ajouter parcours
  if(!empty(request('ajouter'))){
    if(!empty(request('noms_entreprises'))){
      for ($i = 0; $i <count(request('num_etudiants'));$i++) {
    //on insert(ou pas) l'entreprise
    DB::table('Entreprise')
      ->updateOrInsert(
        ['nom_entreprise' =>request('noms_entreprises')[$i]],

        ['nom_entreprise' => request('noms_entreprises')[$i]]);

    //on recupere l'identifiant de cet entreprise

    $id_entr=DB::table('Entreprise')
      ->where('nom_entreprise', request('noms_entreprises')[$i])
      ->take(1)
      ->value('id_entreprise');

    //on cree ensuite la mission

    DB::table('Mission')
      ->insert(['titre' => request('titres')[$i],
      'description' => request('descriptions')[$i],
      'maitre_apprentissage' => request('maitres_apprentissages')[$i],
      'date_debut' => request('dates_debuts')[$i],
      'date_fin' => request('dates_fins')[$i],
      'id_entreprise'=>$id_entr
    ]);

    //on recupere l'identifiant de cette Mission
    $id_m=DB::table('Mission')
          ->where('id_entreprise',$id_entr)
          ->take(1)
          ->value('id_mission');

    //on ajoute cet identifant dans la tabel effectue
    DB::table('Effectue')
    ->insert(
      ['id_miagiste' => request('num_etudiants')[$i],
    'id_mission'=> $id_m]);


  }
}
}



  //diplome
  if(!empty(request('diplome'))  && !empty(request('choix'))){

    for ($i=0; $i <count(request('choix')); $i++) {

      DB::table('Miagiste')
        ->updateOrInsert(
          ['id_miagiste' =>request('choix')[$i]],
          ['diplome' => 1]);
    }

  }

  // 3539273488
  if(!empty(request('passer'))){

    for ($i = 0; $i <count(request('num_etudiants'));$i++) {

      //on recupere l'identifiant de la promotion
      $id_promo=DB::table('Promotion')
        ->where('voie', request('voies')[$i])
        ->where('annee', request('annees')[$i])
        ->where('libelle', request('promotions')[$i])
        ->take(1)
        ->value('id_promotion');

      //on l'ajoute dans la table Est_de_passage
      DB::table('Est_de_passage')
        ->insert(
          ['id_promotion' => $id_promo,
        'id_miagiste' => request('num_etudiants')[$i]
      ]);
    }
  }

  //suppression de plusieurs etudiants
  if(!empty(request('supprimer_etudiants'))){
    DB::table('Est_de_passage')
    ->whereIn('id_miagiste',request('choix'))
    ->delete();

    DB::table('Effectue')
    ->whereIn('id_miagiste',request('choix'))
    ->delete();

    DB::table('Miagiste')
    ->whereIn('id_miagiste',request('choix'))
    ->delete();
  }


  //suppression d'un seul etudiant
  if(!empty(request('supprimer_etudiant'))){
    DB::table('Est_de_passage')
    ->where('id_miagiste','=',request('num_etudiant'))
    ->delete();

    //suppression dans la table Effectue
    DB::table('Effectue')
    ->where('id_miagiste','=',request('num_etudiant'))
    ->delete();

    //supprission dans la table Miagiste
    DB::table('Miagiste')
    ->where('id_miagiste','=',request('num_etudiant'))
    ->delete();
  }

  $miagiste=DB::table('Miagiste')->get();
  $premiere_annee=DB::table('Promotion')->orderBy('annee','asc')->take(1)->value('annee');
  $num_etudiant=request('num_etudiant');

  return view('accueil',compact('premiere_annee','miagiste'));
});



Route::post('/passage', function(){

  if(empty(request('choix'))){
      return Redirect::back()->withErrors('⚠️ Veuillez cocher sur un étudiant');
  }


    $etudiants=DB::table('Miagiste')
    ->whereIn('Miagiste.id_miagiste',request('choix'))
    ->join('Est_de_passage','Est_de_passage.id_miagiste','=','Miagiste.id_miagiste')
    ->join('Promotion','Promotion.id_promotion','=','Est_de_passage.id_promotion')
    ->orderBy('Miagiste.id_miagiste','desc')
    ->orderBy('Promotion.annee','desc')
    ->orderBy('Promotion.libelle','desc')
    ->get();

  $etudiant=$etudiants[0]->id_miagiste;
  for ($i=1; $i < count($etudiants); $i++) {

    if($etudiants[$i]->id_miagiste==$etudiant){
      $etudiants[$i]->id_miagiste=0;
    }
    else {
      $etudiant=$etudiants[$i]->id_miagiste;
    }
  }


  $miagiste=DB::table('Miagiste')->get();
  $premiere_annee=DB::table('Promotion')->orderBy('annee','asc')->take(1)->value('annee');
  $num_etudiant=request('num_etudiant');

  return view('passage',compact('premiere_annee','miagiste','etudiants'));

});



Route::get('/miagistes/{annee}/{promo}/{voie}', function(){


  $miagiste=DB::table('Miagiste')->get();
  $premiere_annee=DB::table('Promotion')->orderBy('annee','asc')->take(1)->value('annee');

  $etudiants_avec_mission=DB::table('Miagiste')
                  ->join('Effectue','Effectue.id_miagiste','=','Miagiste.id_miagiste')
                  ->join('Mission','Mission.id_mission','=','Effectue.id_mission')
                  ->join('Entreprise','Entreprise.id_entreprise','=','Mission.id_entreprise')
                  ->join('Est_de_passage','Est_de_passage.id_miagiste','=','Miagiste.id_miagiste')
                  ->join('Promotion','Promotion.id_promotion','=','Est_de_passage.id_promotion')
                  ->where('Promotion.annee',request('annee'))
                  ->where('Promotion.libelle',request('promo'))
                  ->where('Promotion.voie',request('voie'))
                  ->whereYear('Mission.date_fin', request('annee')+1)
                  ->get();


  $etudiants_sans_mission=DB::table('Miagiste')
                  ->join('Est_de_passage','Est_de_passage.id_miagiste','=','Miagiste.id_miagiste')
                  ->join('Promotion','Promotion.id_promotion','=','Est_de_passage.id_promotion')
                  ->where('Promotion.annee',request('annee'))
                  ->where('Promotion.libelle',request('promo'))
                  ->where('Promotion.voie',request('voie'))
                  ->whereNotIn('Miagiste.id_miagiste', function($q){
                      $q->select('Effectue.id_miagiste')
                        ->from('Effectue')
                        ->join('Mission','Mission.id_mission','=','Effectue.id_mission')
                        ->whereYear('Mission.date_fin', request('annee')+1);
                  })
                  ->get();

  $annee=request('annee');
  $promo=request('promo');
  $voie=request('voie');


  return view('miagistes',compact('voie','promo','annee','premiere_annee','miagiste','etudiants_avec_mission','etudiants_sans_mission'));

});



Route::get('import-excel', 'ImportExcelController@index');

Route::post('import-excel', 'ImportExcelController@import');




Route::post('/ajout', function () {

  if (empty((request('choix'))))return Redirect::back()->withErrors('Veuillez cocher sur un étudiant');
  $premiere_annee=DB::table('Promotion')->orderBy('annee','asc')->take(1)->value('annee');


  $miagiste=DB::table('Miagiste')->get();

  $choix=request('choix');

  $nom = DB::table('Miagiste')
  ->whereIn('id_miagiste',request("choix"))
  ->get();

  $liste_entreprises=DB::table('Entreprise')->get();

  $liste_missions=DB::table('Mission')->get();
  return view('ajout',compact('miagiste','nom','choix','premiere_annee','liste_entreprises','liste_missions'));
});


Route::GET('/ajout-etudiant', function () {

  $premiere_annee=DB::table('Promotion')->orderBy('annee','asc')->take(1)->value('annee');
  $miagiste=DB::table('Miagiste')->get();

  $liste_missions=DB::table('Mission')->get();
  return view('ajout-etudiant',compact('miagiste','premiere_annee'));

});



Route::get('exportView', 'ExportExcelController@exportView');
Route::post('export', 'ExportExcelController@export')->name('export');
